import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

export class Account {
  constructor(
    public accountId: string,
    public accountName: string,
    public company: string,
    public address: string,
    public emailAddress: string,
    public dicomId: string,
    public enabled: number
  ) {}
}

export class User {
  constructor(
    public userId: string,
    public account: Account,
    public userName: string,
    public emailAddress: string,
    public password: string,
    public enabled: number,
    public lastLogin: string
  ) {}
}

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {
  constructor(private httpClient: HttpClient) {}

  getAccounts() {
    return this.httpClient.get<Account[]>('http://localhost:9898/api/v1/accountmanage/accounts');
  }

  /*
  public deleteAccount(account) {
    return this.httpClient.delete<User>(
      'http://localhost:9898/api/v1/accountmanage/account' + '/' + account.accountId
    );
  }

  public createAccount(account) {
    return this.httpClient.post<Account>(
      'http://localhost:9898/api/v1/accountmanage/account',
      account
    );
  }
   */

  getUsers() {
    return this.httpClient.get<User[]>('http://localhost:9898/api/v1/usermanage/users');
  }

  public deleteUser(user) {
    return this.httpClient.delete<User>(
      'http://localhost:9898/api/v1/usermanage/user' + '/' + user.userId
    );
  }

  public createUser(user) {
    return this.httpClient.post<User>(
      'http://localhost:9898/api/v1/usermanage/user',
      user
    );
  }
}
